# Reporting Security Issues

Security issues should be reported privately, via email, to the Pepr Security Team at [email](mailto:pepr@defenseunicorns.com). You should receive a response within 24 hours. If for some reason you do not, please follow up via email to ensure we received your original message.
