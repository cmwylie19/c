# Pepr Talks

## 2024

### Kubernetes Community Days Guadalajara + Open Source Contributor Summit

**February 23-24, 2024**
Optimizing Kubernetes Ecosystems: Leveraging Fluent, Flexible APIs for Admission Control Strategies

***Session Recording***
Coming Soon

***Session Abstract***
Coming Soon

***Where***
Guadalajara, Mexico

***When***
February 23-24, 2024

## 2023

### CNCF South Florida

**December 14, 2023**
Optimizing Kubernetes Ecosystems: Leveraging Fluent, Flexible APIs for Admission Control Strategies

***Session Recording***
[Optimizing Kubernetes Ecosystems: Leveraging Fluent, Flexible APIs for Admission Control Strategies](https://www.youtube.com/watch?v=32xhSJPMtBU&t=12s)

***Session Abstract***
Get ready for an insightful session as Case Wylie, Lead Software Engineer at a Defense unicorn, takes the stage to delve into Kubernetes' Admission Controller. With practical examples and deep expertise backed by certifications in Kubernetes (CKAD, CKA, CKS), Case will guide us through leveraging Fluent, Flexible APIs to optimize your Kubernetes environment

***Where***
Virtual Event - https://community.cncf.io/events/details/cncf-south-florida-presents-optimizing-kubernetes-ecosystems-leveraging-fluent-flexible-apis-for-admission-control-strategies/

***When***
December 14, 2023, 6:00 PM (EST)
