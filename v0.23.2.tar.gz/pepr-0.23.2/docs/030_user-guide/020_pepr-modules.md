# Pepr Modules

## What is a Pepr Module?

A Pepr Module is a collection of files that can be used to create a new Pepr Project. A Pepr Module can be used to create a new Pepr Project by using the `npx pepr init` command.

